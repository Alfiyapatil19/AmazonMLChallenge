import argparse
import os
import pickle
import sqlite3
import tempfile
import time
from typing import Dict, List, Set, Tuple

import numpy as np
import pandas as pd

from src.features import FEATURE_NAMES, extract_pair_features
from src.normalization import normalize_country, normalize_text, standardize_address_text
from src.tokenization import extract_address_tokens, extract_name_ngrams, extract_name_tokens


def build_disk_index(database_path: str, target_paths: List[str]) -> sqlite3.Connection:
    connection = sqlite3.connect(database_path)
    connection.execute("PRAGMA journal_mode=OFF")
    connection.execute("PRAGMA synchronous=OFF")
    connection.execute("PRAGMA temp_store=FILE")
    connection.execute("PRAGMA cache_size=-65536")
    connection.executescript(
        "CREATE TABLE records (entity_id TEXT PRIMARY KEY, name TEXT, address TEXT, country TEXT);"
        "CREATE TABLE postings (token TEXT NOT NULL, entity_id TEXT NOT NULL);"
    )

    record_batch: List[Tuple[str, str, str, str]] = []
    posting_batch: List[Tuple[str, str]] = []
    total_records = 0

    def flush() -> None:
        nonlocal total_records
        if not record_batch:
            return
        connection.executemany(
            "INSERT INTO records VALUES (?, ?, ?, ?)", record_batch
        )
        connection.executemany(
            "INSERT INTO postings VALUES (?, ?)", posting_batch
        )
        total_records += len(record_batch)
        record_batch.clear()
        posting_batch.clear()
        connection.commit()
        if total_records % 250000 < 5000:
            print(f"Indexed {total_records:,} test target records", flush=True)

    for path in target_paths:
        chunks = pd.read_csv(
            path,
            sep="\t",
            usecols=["entity_id", "business_name", "business_address", "country"],
            dtype=str,
            keep_default_na=False,
            chunksize=5000,
            encoding="utf-8",
        )
        for chunk in chunks:
            for entity_id, business_name, business_address, raw_country in zip(
                chunk["entity_id"],
                chunk["business_name"],
                chunk["business_address"],
                chunk["country"],
            ):
                name = normalize_text(business_name)
                address = standardize_address_text(business_address)
                country = normalize_country(raw_country)
                record_batch.append((entity_id, name, address, country))

                tokens: Set[str] = set(extract_name_tokens(name))
                tokens.update(extract_address_tokens(address))
                tokens.update(extract_name_ngrams(name, n=4))
                posting_batch.extend((token, entity_id) for token in tokens)
                if len(record_batch) >= 5000:
                    flush()
    flush()

    print("Building disk-backed token index...", flush=True)
    connection.execute(
        "CREATE UNIQUE INDEX postings_token_entity ON postings(token, entity_id)"
    )
    connection.execute(
        "CREATE TABLE token_counts AS "
        "SELECT token, COUNT(*) AS post_count FROM postings GROUP BY token"
    )
    connection.execute("CREATE UNIQUE INDEX token_counts_token ON token_counts(token)")
    connection.executescript(
        "CREATE TEMP TABLE query_tokens (token TEXT PRIMARY KEY, max_count INTEGER);"
        "CREATE TEMP TABLE rank_tokens (token TEXT PRIMARY KEY, weight INTEGER);"
        "CREATE TEMP TABLE candidate_ids (entity_id TEXT PRIMARY KEY) WITHOUT ROWID;"
    )
    connection.commit()
    return connection


def generate_ranked_candidates(
    connection: sqlite3.Connection,
    name: str,
    address: str,
    name_tokens: Set[str],
    address_tokens: Set[str],
) -> List[str]:
    all_name_tokens = set(extract_name_tokens(name))
    all_address_tokens = set(extract_address_tokens(address))
    name_ngrams = set(extract_name_ngrams(name, n=4))

    caps = {token: 2000 for token in all_name_tokens}
    caps.update(
        {
            token: 4000 if token.startswith(("sh_", "num_")) else 1500
            for token in all_address_tokens
        }
    )
    caps.update({token: 200 for token in name_ngrams})

    connection.execute("DELETE FROM query_tokens")
    connection.executemany(
        "INSERT INTO query_tokens VALUES (?, ?)", caps.items()
    )
    connection.execute("DELETE FROM candidate_ids")
    connection.execute(
        "INSERT OR IGNORE INTO candidate_ids "
        "SELECT p.entity_id FROM postings p "
        "JOIN query_tokens q ON q.token = p.token "
        "JOIN token_counts c ON c.token = p.token "
        "WHERE c.post_count <= q.max_count"
    )

    if connection.execute("SELECT 1 FROM candidate_ids LIMIT 1").fetchone() is None:
        rarest = connection.execute(
            "SELECT q.token FROM query_tokens q "
            "JOIN token_counts c ON c.token = q.token "
            "ORDER BY c.post_count, q.token LIMIT 1"
        ).fetchone()
        if rarest is not None:
            connection.execute(
                "INSERT OR IGNORE INTO candidate_ids "
                "SELECT entity_id FROM postings WHERE token = ?",
                rarest,
            )

    candidates = [
        row[0] for row in connection.execute("SELECT entity_id FROM candidate_ids")
    ]
    if not candidates:
        return []

    weights = {token: 2 for token in name_tokens}
    weights.update({token: 1 for token in address_tokens})
    connection.execute("DELETE FROM rank_tokens")
    connection.executemany(
        "INSERT INTO rank_tokens VALUES (?, ?)", weights.items()
    )
    overlap = dict(
        connection.execute(
            "SELECT p.entity_id, SUM(r.weight) "
            "FROM postings p "
            "JOIN rank_tokens r ON r.token = p.token "
            "JOIN candidate_ids c ON c.entity_id = p.entity_id "
            "GROUP BY p.entity_id"
        )
    )
    ranked = [(overlap.get(entity_id, 0), entity_id) for entity_id in candidates]
    ranked.sort(key=lambda item: item[0], reverse=True)
    return [entity_id for _, entity_id in ranked[:60]]


def apply_decision_rule(
    candidate_ids: List[str], probabilities: np.ndarray
) -> List[str]:
    if not candidate_ids:
        return []
    max_probability = float(np.max(probabilities))
    if max_probability < 0.985:
        return []
    accepted = [
        (entity_id, float(probability))
        for entity_id, probability in zip(candidate_ids, probabilities)
        if probability >= 0.985 and probability >= max_probability - 0.005
    ]
    accepted.sort(key=lambda item: item[1], reverse=True)
    return sorted(entity_id for entity_id, _ in accepted[:7])


def verify_matching_output(
    s1_test_path: str,
    matching_path: str,
    chunksize: int = 100000,
) -> Tuple[int, int, int, int]:
    expected_rows = 0
    output_rows = 0

    with tempfile.TemporaryDirectory(prefix="entity_resolution_verify_") as temp_dir:
        connection = sqlite3.connect(os.path.join(temp_dir, "coverage.sqlite3"))
        connection.executescript(
            "CREATE TABLE expected (entity_id TEXT PRIMARY KEY);"
            "CREATE TABLE output (entity_id TEXT NOT NULL);"
        )

        for chunk in pd.read_csv(
            s1_test_path,
            sep="\t",
            usecols=["entity_id"],
            dtype=str,
            keep_default_na=False,
            chunksize=chunksize,
            encoding="utf-8",
        ):
            ids = [(entity_id,) for entity_id in chunk["entity_id"]]
            expected_rows += len(ids)
            connection.executemany(
                "INSERT OR IGNORE INTO expected VALUES (?)", ids
            )

        for chunk in pd.read_csv(
            matching_path,
            sep="\t",
            usecols=["source1_entity_id"],
            dtype=str,
            keep_default_na=False,
            chunksize=chunksize,
            encoding="utf-8",
        ):
            ids = [(entity_id,) for entity_id in chunk["source1_entity_id"]]
            output_rows += len(ids)
            connection.executemany("INSERT INTO output VALUES (?)", ids)

        missing = connection.execute(
            "SELECT COUNT(*) FROM expected e "
            "LEFT JOIN output o ON o.entity_id = e.entity_id "
            "WHERE o.entity_id IS NULL"
        ).fetchone()[0]
        duplicates = connection.execute(
            "SELECT COALESCE(SUM(row_count - 1), 0) FROM ("
            "SELECT COUNT(*) AS row_count FROM output "
            "GROUP BY entity_id HAVING COUNT(*) > 1)"
        ).fetchone()[0]
        connection.close()

    return expected_rows, output_rows, int(missing), int(duplicates)


def run(args: argparse.Namespace) -> int:
    with open(args.model, "rb") as model_file:
        artifact = pickle.load(model_file)
    if artifact.get("feature_names") != FEATURE_NAMES or artifact.get("feature_count") != 33:
        raise ValueError("Saved model metadata does not match the current 33-feature extractor.")
    if artifact["model"].get_booster().num_features() != 33:
        raise ValueError("Saved model does not accept exactly 33 features.")
    expected_config = {
        "hard_negatives_per_entity": 15,
        "n_estimators": 300,
        "max_depth": 5,
        "learning_rate": 0.04,
        "subsample": 0.88,
        "colsample_bytree": 0.88,
        "min_child_weight": 3,
        "reg_alpha": 0.15,
        "reg_lambda": 1.2,
        "random_state": 42,
        "threshold": 0.985,
        "margin": 0.005,
        "max_k": 7,
    }
    if artifact.get("config") != expected_config:
        raise ValueError("Saved model configuration differs from the requested configuration.")

    output_dir = os.path.abspath(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)
    matching_path = os.path.join(output_dir, "matching_results.tsv")
    matching_temp = matching_path + ".tmp"
    for path in (matching_path, matching_temp):
        if os.path.exists(path):
            raise FileExistsError(f"Refusing to overwrite existing file: {path}")

    with tempfile.TemporaryDirectory(prefix="entity_resolution_final_") as temp_dir:
        database_path = os.path.join(temp_dir, "test_targets.sqlite3")
        connection = build_disk_index(database_path, [args.s2_test, args.s3_test])
        model = artifact["model"]
        processed = 0
        total_candidates = 0
        started = time.time()

        with open(args.s1_test, "r", encoding="utf-8", newline="") as s1_file, \
            open(matching_temp, "x", encoding="utf-8", newline="") as matching_file:
            s1_reader = csv.reader(s1_file, delimiter="\t")
            positions = {name: index for index, name in enumerate(next(s1_reader))}
            matching_file.write("source1_entity_id\tmatched_entity_ids\n")

            while True:
                batch = []
                for _ in range(args.s1_batch_size):
                    try:
                        row = next(s1_reader)
                    except StopIteration:
                        break
                    entity_id = read_field(row, positions, "entity_id")
                    name = normalize_text(read_field(row, positions, "business_name"))
                    address = standardize_address_text(
                        read_field(row, positions, "business_address")
                    )
                    country = normalize_country(read_field(row, positions, "country"))
                    name_tokens = set(extract_name_tokens(name))
                    address_tokens = set(extract_address_tokens(address))
                    candidate_ids = generate_ranked_candidates(
                        connection, name, address, name_tokens, address_tokens
                    )
                    total_candidates += len(candidate_ids)
                    batch.append((entity_id, name, address, country, candidate_ids))

                if not batch:
                    break

                flat_candidate_ids = [
                    candidate_id
                    for item in batch
                    for candidate_id in item[4]
                ]
                records: Dict[str, Tuple[str, str, str]] = {}
                for start in range(0, len(flat_candidate_ids), 500):
                    id_chunk = flat_candidate_ids[start:start + 500]
                    placeholders = ",".join("?" for _ in id_chunk)
                    records.update(
                        {
                            entity_id: (name, address, country)
                            for entity_id, name, address, country in connection.execute(
                                "SELECT entity_id, name, address, country FROM records "
                                f"WHERE entity_id IN ({placeholders})",
                                id_chunk,
                            )
                        }
                    )

                feature_rows = []
                offsets = []
                for entity_id, name, address, country, candidate_ids in batch:
                    start = len(feature_rows)
                    for candidate_id in candidate_ids:
                        if candidate_id not in records:
                            raise RuntimeError(f"Candidate record missing from test targets: {candidate_id}")
                        candidate_name, candidate_address, candidate_country = records[candidate_id]
                        feature_rows.append(
                            extract_pair_features(
                                name,
                                address,
                                country,
                                candidate_name,
                                candidate_address,
                                candidate_country,
                                cand_id=candidate_id,
                            )
                        )
                    offsets.append((entity_id, candidate_ids, start, len(feature_rows)))

                probabilities = (
                    model.predict_proba(np.asarray(feature_rows, dtype=np.float32))[:, 1]
                    if feature_rows
                    else np.asarray([], dtype=np.float32)
                )
                for entity_id, candidate_ids, start, end in offsets:
                    matches = apply_decision_rule(candidate_ids, probabilities[start:end])
                    matching_file.write(f"{entity_id}\t{','.join(matches)}\n")
                processed += len(batch)
                if processed % 10000 < args.s1_batch_size:
                    print(
                        f"Scored {processed:,} Source 1 rows; "
                        f"{total_candidates:,} candidates; "
                        f"{time.time() - started:.1f}s elapsed",
                        flush=True,
                    )

        connection.close()

    os.rename(matching_temp, matching_path)
    print(f"Test Source 1 rows: {processed:,}")
    print(f"Candidate pairs scored: {total_candidates:,}")
    print(f"Matching results: {matching_path}")
    return processed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--s1-test", default="test/test_source1.tsv")
    parser.add_argument("--s2-test", default="test/test_source2.tsv")
    parser.add_argument("--s3-test", default="test/test_source3.tsv")
    parser.add_argument("--model", default="models/er_matcher_final_tau0985_delta0005_k7.pkl")
    parser.add_argument("--output-dir", default="output/reproduced_96_19")
    parser.add_argument("--s1-batch-size", type=int, default=64)
    args = parser.parse_args()
    run(args)


if __name__ == "__main__":
    main()