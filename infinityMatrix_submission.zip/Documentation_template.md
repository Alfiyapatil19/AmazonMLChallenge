# Business Entity Resolution Methodology

## Objective

For each Source 1 business, identify matching records in Sources 2 and 3. The output associates each Source 1 entity ID with a comma-separated list of matched target entity IDs; an empty field represents no predicted match.

## Data preparation

Business names, addresses, and countries are normalized before comparison. Records are processed by normalized country. Name and address text are tokenized; the blocker also derives address shingles/numbers and character n-grams from business names.

## Candidate generation

The country-partitioned inverted index unions candidates found through name tokens, address tokens, and name n-grams. Frequency caps limit common postings: 2,000 for name tokens, 1,500 for address words, 4,000 for address shingles/numbers, and 200 for name n-grams. When these caps yield no candidate, the index falls back to the rarest available query token. This reduces pairwise comparisons while retaining a fallback path for sparse records.

## Pair matching

Each query-candidate pair is represented by 33 features extracted from the business name, address, country, and candidate ID. The matcher uses an XGBoost binary classifier with 300 estimators, depth 5, learning rate 0.04, row and column subsampling of 0.88, minimum child weight 3, L1 regularization 0.15, L2 regularization 1.2, and random seed 42. The implementation has a scikit-learn fallback if XGBoost is unavailable; the pinned environment installs XGBoost.

## Decision rule and evaluation

The standard pipeline accepts pair probabilities at or above its configured threshold (default 0.70). The dedicated final-inference runner validates a stricter model configuration: threshold 0.985, probability margin 0.005 from the best candidate, and at most 7 matches. Training utilities evaluate macro-averaged F0.5 and support threshold optimization.

## Output and reproducibility

`matching_results.tsv` uses the columns `source1_entity_id` and `matched_entity_ids`. `candidate_pairs.tsv` uses `source1_entity_id` and `candidate_entity_ids`. The README gives commands for training and full test inference.

The files included in this example archive are intentionally not final outputs: the matching sample is copied from labeled training ground truth, and the candidate sample contains only those positive labels. They demonstrate the TSV schemas but do not represent predictions, a complete blocked candidate set, or leaderboard performance. Generate both files from the test data before submission.