# Business Entity Resolution

> This archive is an example bundle, not a leaderboard submission. Its matching results are 5,000 labeled training examples, and its candidate pairs contain only those known positive IDs. Neither output is a complete test-set inference result.

## Reproduce the pipeline

Use Python 3.13.5 (the environment used to pin `requirements.txt`). Place the supplied dataset files under this project directory using the paths below:

```text
train/train_source1.tsv
train/train_source2.tsv
train/train_source3.tsv
train/train_ground_truth.tsv
test/test_source1.tsv
test/test_source2.tsv
test/test_source3.tsv
```

Create an environment and install the pinned dependencies:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Train and evaluate the matcher, then run inference to generate both official-format output files:

```powershell
.venv\Scripts\python.exe run_pipeline.py --mode train --model_path models/er_matcher.pkl
.venv\Scripts\python.exe run_pipeline.py --mode test --model_path models/er_matcher.pkl --out_matching ../../output/matching_results.tsv --out_candidate ../../output/candidate_pairs.tsv
```

Run these commands from `code/business_entity_resolution`. The test command uses the pipeline's default decision threshold of `0.70`. To use the stricter final-inference runner, provide its compatible trained model artifact and the three test files:

```powershell
.venv\Scripts\python.exe run_final_test_inference.py --s1-test test/test_source1.tsv --s2-test test/test_source2.tsv --s3-test test/test_source3.tsv --model models/er_matcher_final_tau0985_delta0005_k7.pkl --output-dir ../../output/reproduced_96_19
```

That runner applies its saved configuration (threshold `0.985`, margin `0.005`, maximum 7 matches) and writes `matching_results.tsv` under the selected output directory. It does not generate `candidate_pairs.tsv`.

## Project files

- `src/`: normalization, tokenization, candidate generation, feature extraction, matching, metrics, and pipeline implementation.
- `run_pipeline.py`: train/evaluate and full test inference entrypoint.
- `run_final_test_inference.py`: disk-backed final matcher inference entrypoint.
- `run_blocking.py`: blocking and candidate-generation evaluation entrypoint.
- `tests/`: unit and end-to-end tests.
- `requirements.txt`: pinned Python dependencies.

See the archive's `Documentation_template.md` for the methodology summary. Replace both sample files under `output/` with complete test inference outputs before submitting to a leaderboard.